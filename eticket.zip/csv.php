<?php

include 'functions.php';

download_csv_results();

?>