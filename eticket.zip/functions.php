<?php
/*****************************************************************************
*	File: 		functions.php
*	Purpose: 	Contains all common functions used within the IT&E
*				Ticketing Script
*	Author:		Tim Dominguez (timfox@coufu.com)
*   Date:       2/12/2013
******************************************************************************/

include "drtlib.php";
include "config.php";

//Displays the header (top) of the pages
function ticket_top ( $title = NULL, $width = 600){	
	echo "<html>";
	echo "<head>";
	echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">";
	echo '<link rel="stylesheet" href="js/jquery-ui-1.10.2.custom.min.css" />
			<script src="js/jquery-1.9.1.js"></script>
			<script src="js/jquery-ui-1.10.2.custom.min.js"></script>
			<link rel="stylesheet" href="/resources/demos/style.css" />
			<script>
				$(function() {
				$( "#datepicker" ).datepicker();
				$( "#datepicker2" ).datepicker();
			});
			</script>';
	echo "<title>IT&E Help Desk ";
	if($title)	echo "[ $title ]";
	echo "</title>";
	echo "</head>";
	echo "<body>";
	echo "<center>";
	$tbl = new Ctable;
	$tbl->push( array ( "<a href=\"login.php\"><img src=\"presales_banner.jpg\" border=0></a>" ) );
	$tbl->show();
	echo "<br>";
	
	//Navigation (Only appears if the user is logged in)
	if( $_COOKIE[userid] ){
		$username = getusername( $_COOKIE[userid] );
		$table = new Ctable;
		$table->setwidth( "$width" );
		$table->push( "Hello, <b>$username</b>", "<p align=\"right\"><a href=\"index.php\">Home</a> | <a href=\"admin.php\">Tickets</a> | <a href=\"users.php\">Users</a> | <a href=\"report.php\">Reports</a> | <a href=\"login.php?action=logout\">Logout</a>" );		
		$table->show();
	}
}

//Displays Bottom of the Page
function ticket_bottom( $coolline = NULL, $width = 600){
	if ( $coolline ){
		$table = new Ctable;
		$table->setwidth( "$width" );
		$table->pushth( " " );
		$table->show();
		echo "<br><font size=\"1\"><a href=\"login.php\">&copy;</a>Copyright <a href=\"mailto:tim.dominguez@itehq.net\">IT&E</a><br>";
	}
	else {
		echo "<br><font size=\"1\"><a href=\"login.php\">&copy;</a>Copyright <a href=\"mailto:tim.dominguez@itehq.net\">IT&E</a><br>";
	}
}	

//Login (and/or permission) check 
function members_only( $permission = NULL ) {
	//This checks if the function states if only admin can view the page
	if ( $permission == "admin" ) {
		$db = new MyDB;
		$db->query( "SELECT groupid FROM users WHERE id = '$_COOKIE[userid]'");
		$row = $db->getrow();
		if  ( $row[groupid] != 1 )
			$error = TRUE;
	}
	//If they aren't logged in, error.
	if (!$_COOKIE[userid])
		$error = TRUE; 
	
	//If there are any errors, this kills the script and redirects them to the index page. 
	if ( $error ) {
		redirect( "index.php", 2,  "Access Denied", "You do not have correct privileges to view this page. Go away" );
		exit;
	}
}

//Getting the group name from the id
function getgroupname ( $id ){
	if( $id == 1 )
		$groupname = "Godlike";
	if( $id == 2 ) 
		$groupname = "Information Management";
	if( $id == 3 )
		$groupname = "Presales";
	return $groupname;
}

//Getting groupname from userid
function getusergroupname ( $userid ) {
	ticketmysqlconnect();
	$result = mysql_query ("SELECT * from users WHERE id = '$userid'"); 
	$row = mysql_fetch_array ( $result, MYSQL_ASSOC);
	
	if( $row[groupid] == 1 )
		$groupname = "Godlike";
	if( $row[groupid] == 2 ) 
		$groupname = "Information Management";
	if( $row[groupid] == 3 )
		$groupname = "Presales";
	return $groupname;
}

//Getting groupid from userid
function getusergroupid( $userid ){
	ticketmysqlconnect();
	$result = mysql_query ("SELECT * from users WHERE id = '$userid'"); 
	$row = mysql_fetch_array ( $result, MYSQL_ASSOC);
	$groupid = "$row[groupid]";
	return $groupid;
}

//Adding a cool looking line hehe
function addcoolline( $width = 450) {
	$table = new Ctable;
	$table->setwidth( "$width" );
	$table->pushth( " " );
	$table->show();
}

//Getting the username from the userid
function getusername( $id ) {
	ticketmysqlconnect();
	$result = mysql_query( 'SELECT username FROM users WHERE id = '.$id.'' );
	$row = mysql_fetch_array ( $result, MYSQL_ASSOC);
	$username = $row[username];
	return $username;
}

//Getting location name from location id
function getlocationname( $id ){
	if ( $id == 1 )
		$location = 'Harmon';
	if ( $id == 2)
		$location = 'Micronesia Mall';
	if ( $id == 3)
		$location = 'Agana';
	if ( $id == 4)
		$location = 'GPO';
	if ( $id == 5)
		$location = 'Macheche';
	if ( $id == 6)
		$location = 'AAFES';
	
	return $location;
}

//Getting category name
function getcategoryname( $id ){
	ticketmysqlconnect();
	$result       = mysql_query('SELECT name FROM categories WHERE categoryid = '.$id.'');
	$categoryname = mysql_fetch_array($result);
	$categoryname = $categoryname[0];
	return $categoryname;
}

//Outputting CSV


//Setting the timezone (for Guam time) for date functions
date_default_timezone_set( 'Etc/GMT-10' );

//debuginfo();

?>